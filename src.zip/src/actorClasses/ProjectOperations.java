package actorClasses;

public interface ProjectOperations {

	
	public String[][] builderPerformanceTracking();
	public String[][] projectStatus(String pId);
	
}
	